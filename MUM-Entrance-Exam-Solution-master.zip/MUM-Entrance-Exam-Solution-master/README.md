# MUM-Entrance-Exam-Solution
Questions are in the pdf file.
